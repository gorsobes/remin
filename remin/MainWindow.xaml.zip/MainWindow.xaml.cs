﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace remin
{
    public partial class MainWindow : Window
    {
        private const string FilePath = "reminders.txt";
        private const string HistoryFilePath = "history.txt";

        public ObservableCollection<string> Reminders { get; set; } = new ObservableCollection<string>();

        public MainWindow()
        {
            InitializeComponent();
            Reminders = new ObservableCollection<string>(); // Инициализация коллекции
            DataContext = this; // Установка контекста данных
            LoadReminders(); // Загрузка напоминаний
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(InputTextBox.Text))
            {
                string text = InputTextBox.Text;
                string date = ReminderDatePicker.SelectedDate?.ToString("dd.MM.yyyy") ?? DateTime.Today.ToString("dd.MM.yyyy");
                string time = ReminderTimePicker.SelectedItem is ComboBoxItem selectedItem && selectedItem.Content.ToString() != "--:--"
                              ? selectedItem.Content.ToString()
                              : "00:00";

                string reminder = $"{date} {time} {text}";
                Reminders.Add(reminder);

                InputTextBox.Clear();
                AddButton.IsEnabled = false;
                SaveReminders();
            }
        }



        private void ReminderTimePicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AddButton.IsEnabled = !string.IsNullOrWhiteSpace(InputTextBox.Text);
        }


        private void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(HistoryFilePath))
            {
                string historyContent = File.ReadAllText(HistoryFilePath);
                MessageBox.Show(historyContent, "История удаленных напоминаний", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("История пуста.", "История", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void InputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            AddButton.IsEnabled = !string.IsNullOrWhiteSpace(InputTextBox.Text);
        }

        private void InputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && AddButton.IsEnabled)
            {
                AddButton_Click(sender, e);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (RemindersList.SelectedItem != null)
            {
                MessageBoxResult result = MessageBox.Show("Точно удалить?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    string deletedReminder = RemindersList.SelectedItem.ToString();

                    // Удаляем из ObservableCollection (оно связано с ListBox)
                    Reminders.Remove(deletedReminder);

                    // Сохраняем новый список в файл
                    SaveReminders();

                    // Добавляем в историю
                    SaveToHistory(deletedReminder);
                }
            }
        }


        private void SaveReminders() => File.WriteAllLines(FilePath, Reminders);

        private void LoadReminders()
        {
            if (File.Exists(FilePath))
            {
                Reminders.Clear(); // Очистим список перед загрузкой
                var reminders = File.ReadAllLines(FilePath);
                foreach (var reminder in reminders)
                {
                    Reminders.Add(reminder);
                }
            }
        }


        private void SaveToHistory(string reminder) => File.AppendAllText(HistoryFilePath, reminder + Environment.NewLine);

        private void ShowAllButton_Click(object sender, RoutedEventArgs e)
        {
            ReminderDatePicker.SelectedDate = null;
        }

        private void ReminderDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyDateFilter();
        }

        private void ApplyDateFilter()
        {
            var selectedDate = ReminderDatePicker.SelectedDate?.ToString("dd.MM.yyyy");
            RemindersList.ItemsSource = selectedDate == null ? Reminders : new ObservableCollection<string>(Reminders.Where(r => r.StartsWith(selectedDate)));
        }

        private void RemindersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DeleteButton.IsEnabled = RemindersList.SelectedItem != null;
        }
    }
}
